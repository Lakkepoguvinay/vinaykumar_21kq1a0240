Python 3.10.11 (tags/v3.10.11:7d4cc5a, Apr  5 2023, 00:38:17) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: C:/Users/lakke/OneDrive/Documents/Zoom/1.py =============
Enter the number of courses: 5

Enter details for Course 1:
Enter course name: python
Enter course fee: $1000
Enter number of enrolled students: 50
Enter total number of seats: 100
Enter course duration: 30 days

Enter details for Course 2:
Enter course name: java
Enter course fee: $1500
Enter number of enrolled students: 70
Enter total number of seats: 80
Enter course duration: 25 days

Enter details for Course 3:
Enter course name: c
Enter course fee: $2000
Enter number of enrolled students: 30
Enter total number of seats: 80
Enter course duration: 60 days

Enter details for Course 4:
Enter course name: c++
Enter course fee: $2050
Enter number of enrolled students: 30
Enter total number of seats: 70
Enter course duration: 20 days

Enter details for Course 5:
Enter course name: oops
Enter course fee: $3000
Enter number of enrolled students: 40
Enter total number of seats: 80
